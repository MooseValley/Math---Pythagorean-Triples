# Math - Pythagorean Triples

## The Problem with 7825 - Numberphile
* https://www.youtube.com/watch?v=1gBwexpG0IY

